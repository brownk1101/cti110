#Karen Brown

#June 6, 2024

#P4LAB1b

#Description
    #This program will draw the initials K B


#import turtle
import turtle

#change the shape to a turtle
turtle.shape("turtle")

#Change the color to teal
turtle.color("teal")

#change the width to 4
turtle.width(4)

#Draw the K
turtle.right(90)
turtle.forward(100)
turtle.backward(50)
turtle.left(140)
turtle.forward(65)
turtle.backward(65)
turtle.right(100)
turtle.forward(65)

#move the turtle over 25 spaces
turtle.up()
turtle.left(50)
turtle.forward(25)
turtle.left(90)
turtle.down()

#Draw the B
turtle.forward(100)
turtle.right(90)
turtle.circle(-25, 180)
turtle.left(180)
turtle.circle(-25, 180)


turtle.exitonclick()
