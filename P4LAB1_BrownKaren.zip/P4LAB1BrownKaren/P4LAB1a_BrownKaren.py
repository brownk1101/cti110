import turtle


turtle.shape("turtle")

side = 0
while side < 4:
    turtle.forward(100)
    turtle.left(90)
    side += 1
for corner in range(0,3):
    turtle.right(120)
    turtle.forward(100)
    


turtle.exitonclick()
